var searchData=
[
  ['_7ebadguy',['~badguy',['../classbadguy.html#ad5d09cf91dc849e14f9fe31b3220aaa9',1,'badguy']]],
  ['_7ebullet',['~Bullet',['../class_bullet.html#aaeb5cb41d7db89f49007b08b41f1bfcf',1,'Bullet']]]
];
