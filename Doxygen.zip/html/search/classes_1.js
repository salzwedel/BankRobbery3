var searchData=
[
  ['endings',['Endings',['../class_endings.html',1,'']]]
];
