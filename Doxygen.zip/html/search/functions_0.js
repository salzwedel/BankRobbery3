var searchData=
[
  ['badguy',['badguy',['../classbadguy.html#a4b6d6fdca626a0267236787fbe20b2ad',1,'badguy']]],
  ['badguy_5fkilled',['badguy_killed',['../class_game.html#a7406d3975dff0cba5c50115d0f050a45',1,'Game']]],
  ['badguy_5fzones',['badguy_zones',['../class_game.html#a978ecd228e6274e192e545b8a49eff9b',1,'Game']]],
  ['badguys_5fonscreen',['badguys_onscreen',['../class_game.html#a6771d472a6adaf1bcc58f997b96f2c16',1,'Game']]],
  ['badguys_5fremaining',['badguys_remaining',['../class_game.html#a1723c85835165e0a3353b58350401cd9',1,'Game']]],
  ['bullet',['Bullet',['../class_bullet.html#a0f8e8b2e3f683cfc930238a7633ce0f2',1,'Bullet']]]
];
