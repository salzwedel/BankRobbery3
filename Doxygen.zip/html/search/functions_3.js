var searchData=
[
  ['hostage',['hostage',['../classhostage.html#a289f13eb03abb9eb0d683d51faf292fc',1,'hostage']]],
  ['hostage_5fkilled',['hostage_killed',['../class_game.html#a080d1ee7b8efcef5834ffec80e0bbdb1',1,'Game']]],
  ['hostage_5fzones',['hostage_zones',['../class_game.html#a90b2ca46a8e37e5a64a9bdce3f4a3e4b',1,'Game']]],
  ['hostages_5fonscreen',['hostages_onscreen',['../class_game.html#a8eb0a78447492976f2af4d69e5f4430e',1,'Game']]],
  ['hostages_5fremaining',['hostages_remaining',['../class_game.html#a132981c00605a3a030510aac18e16636',1,'Game']]]
];
