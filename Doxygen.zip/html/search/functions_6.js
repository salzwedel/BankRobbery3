var searchData=
[
  ['set_5fbadguys_5fzones',['set_badguys_zones',['../class_game.html#ab4807ffbf5ec48e829789fb3390518f1',1,'Game']]],
  ['set_5fhostages_5fzones',['set_hostages_zones',['../class_game.html#ac574b8c3b5287af87d780447c8f34840',1,'Game']]],
  ['setgame',['setGame',['../class_main_window.html#a8716d52cdf2b17540512951c2db27675',1,'MainWindow']]],
  ['shoot',['shoot',['../class_my_player.html#ac00726202004d1d5aef9b7410bfce6ad',1,'MyPlayer']]],
  ['spawn_5fb',['spawn_b',['../class_game.html#af3f86c072631ccffc1e3de01bdfd1b88',1,'Game']]],
  ['spawn_5fh',['spawn_h',['../class_game.html#a46fe3c9b6eb40e67d292b71345a5583b',1,'Game']]]
];
