var searchData=
[
  ['endings',['Endings',['../class_endings.html#aa0a43436cc669e4ddd53260cb04769cf',1,'Endings']]]
];
