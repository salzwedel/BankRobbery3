var searchData=
[
  ['hostage',['hostage',['../classhostage.html',1,'']]]
];
